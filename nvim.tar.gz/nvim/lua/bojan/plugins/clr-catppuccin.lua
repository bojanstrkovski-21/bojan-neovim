return { 
"catppuccin/nvim",
 name = "catppuccin-mocha",
 priority = 1000,
}
